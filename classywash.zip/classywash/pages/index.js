export default function Home() {
  return (
    <div className="min-h-screen bg-white text-gray-900 font-sans">
      <header className="bg-blue-900 text-white py-6 px-4 shadow-md">
        <div className="max-w-5xl mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold">ClassyWash</h1>
          <p className="text-sm">Stay Clean. Stay Classy.</p>
        </div>
      </header>

      <main className="max-w-5xl mx-auto p-4">
        <section className="text-center my-12">
          <h2 className="text-3xl font-semibold mb-4">Professional Cleaning Services in Sydney</h2>
          <p className="text-lg text-gray-600">Residential, Office, Post-Construction & More</p>
        </section>

        <section className="grid md:grid-cols-2 gap-6 my-12">
          {[
            'Residential Cleaning',
            'Move Out Cleaning',
            'Office & Store Cleaning',
            'Post-Construction Cleaning',
            'Restaurant Cleaning',
            'Pressure Washing'
          ].map((service) => (
            <div key={service} className="p-6 border rounded shadow-sm hover:shadow-md transition">
              <h3 className="text-xl font-bold mb-2">{service}</h3>
              <p className="text-gray-600">We provide professional and reliable {service.toLowerCase()} to keep your space spotless and classy.</p>
            </div>
          ))}
        </section>

        <section className="text-center my-12">
          <h2 className="text-2xl font-bold mb-4">Book a Free Quote</h2>
          <p className="text-gray-600 mb-2">Visit <a href="https://classywash.com" className="text-blue-600 underline">classywash.com</a> or email us at <strong>yourclassywash@gmail.com</strong></p>
          <p className="text-gray-600">Call or WhatsApp: <strong>0492 839 791</strong></p>
        </section>
      </main>

      <footer className="bg-blue-900 text-white text-center py-4 mt-12">
        <p>&copy; 2025 ClassyWash. All rights reserved.</p>
      </footer>
    </div>
  );
}